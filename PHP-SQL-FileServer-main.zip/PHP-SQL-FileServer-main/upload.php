<?php
// upload.php

// Connect to the MySQL database
$host = "cydar.ist.psu.edu";
$username = "plant3d";
$password = "Dk5MCnscLKj73XhP";
$dbname = "plant3d";
$conn = mysqli_connect($host, $username, $password, $dbname);


if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the form was submitted
if (isset($_POST['submit'])) {
    // Get the uploaded file data
    $file = $_FILES['file'];

    // Get the file name and extension
    $fileName = $file['name'];
    $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

    // Allow certain file types (tif and tiff)
    $allowedTypes = ['tif', 'tiff'];
    if (!in_array($fileType, $allowedTypes)) {
        echo "Error: Only TIF and TIFF files are allowed.";
        exit;
    }

    // Set the target directory and file name
    $targetDir = "uploads/";
    $targetFile = $targetDir . uniqid() . "." . $fileType;

    // Move the uploaded file to the target directory
    if (move_uploaded_file($file['tmp_name'], $targetFile)) {
        // Open the file and read its contents
        $handle = fopen($targetFile, "r");
        $contents = fread($handle, filesize($targetFile));
        fclose($handle);

        // Escape the contents and insert them into the database
        $contents = mysqli_real_escape_string($conn, $contents);
        $query = "INSERT INTO files (name, type, data) VALUES ('$fileName', '$fileType', '$contents')";
        if (mysqli_query($conn, $query)) {
            echo "File uploaded successfully.";
        } else {
            echo "Error: " . $query . "<br>" . mysqli_error($conn);
        }
    } else {
        echo "Error: There was an error uploading the file.";
    }
}

mysqli_close($conn);

?>
